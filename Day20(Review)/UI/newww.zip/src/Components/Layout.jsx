import React from 'react'
import Navbar from './Navbar'

function Layout() {
  return (
    <div >
        {/*<Topbar/>*/}
        <Navbar/>
    </div>
      )
}

export default Layout