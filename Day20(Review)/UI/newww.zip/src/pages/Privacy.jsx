import React from 'react'
import NavbarHome from '../Components/NavbarHome'
import "../assets/css/Privacy.css"
import Footer from './Footer'

function Privacy() {
  return (
    <div>
        <NavbarHome/>
    <div className='Fullcontent'>
        <h1 className='Titledis'>Privacy Policy-General</h1>

    </div>
    <Footer/>
    </div>
  )
}

export default Privacy